﻿using Newtonsoft.Json;
using System;
using System.Web;

namespace YongyouInvoice
{
    /// <summary>
    /// RedirectResult 的摘要说明
    /// </summary>
    public class RedirectResult : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            string data = Utils.GetRequestData();// 获取当前请求的数据包内容获得返回值
            FinalResult ts =  JsonConvert.DeserializeObject<FinalResult>(data);
            string code = null; string msg = null;
             code=ts.code;
             msg = ts.msg;
            //string fpqqlsh = ts.fpqqlsh;
            //string pdf = ts.pdf;
            //string shareurl = ts.shareurl;
            //string sharecode = ts.sharecode;
            ResponsePara res = new ResponsePara();
            res.code = code;
            res.msg = msg;
            var setting = new JsonSerializerSettings();


            //解决枚举类型序列化时，被转换成数字的问题
            // setting.Converters.Add(new StringEnumConverter());
            string ss = JsonConvert.SerializeObject(res, setting);
            context.Response.ContentType = "application/Json";
            context.Response.Write(ss); 
        }



        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}