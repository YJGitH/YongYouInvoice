﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YongyouInvoice
{
    public class ResponsePara
    {
        public string code { get; set; }
        public string msg { get; set; }
    }
}