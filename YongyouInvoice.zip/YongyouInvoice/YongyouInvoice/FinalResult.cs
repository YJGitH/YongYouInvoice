﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YongyouInvoice
{
    public class FinalResult
    {
        public string code { get; set; }
        public string msg { get; set; }
        public string fpqqlsh { get; set; }
        public string pdf { get; set; }
        public string shareurl { get; set; }
        public string sharecode { get; set; }
        public string data { get; set; }
        public string invoicecode { get; set; }
        public string qrcode { get; set; }
    }
}