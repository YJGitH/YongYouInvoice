﻿using Jose;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace YongyouInvoice
{
    public partial class InvoiceQCode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var baseUrl = "http://www.yesfp.com";
            DateTime now = DateTime.Now;
            string s = now.ToString("yyyyMMddHHmmss");
            var url = string.Format(baseUrl + "/invoiceclient-web/api/invoiceApply/insertForQRInvoice?appid=yesfpTester&ts={0}", s);
            //var url = baseUrl + "/invoiceclient-web/api/invoiceApply/insertWithArray?appid=yesfpTester";
            var req = (HttpWebRequest) WebRequest.Create(url);


            //请求体参数_requestdatas(发票头+发票明细)
            var requestdatas = BuildRequestDatas();

            var paraEnvoice = "requestdatas=" + requestdatas;
            //json数组格式，可以多张发票，流水号关联
            //请求体参数_email(邮件推送配置)
            var paraEmail = "email=" + BuildEmailData();
            //请求体参数_sms(短信推送配置)
            var paraSms = "sms=" + BuildMobileData();
            //json数组格式，可以多手机号，以流水号关联
            //请求体参数_url(回调服务配置)
            var paraUrl = "url=" + HttpUtility.UrlEncode(BuildUrlData()); //json数组格式，可以多url，以流水号关联 
            //拼接参数字符串
            //var param = paraEnvoice + '&' + paraEmail + '&' + paraSms + '&' + paraUrl + "&autoAudit=false";
            var param = paraEnvoice + '&' + paraEmail + '&' + paraSms + '&' + paraUrl ;

            //设置消息头
            // var bs = Encoding.ASCII.GetBytes(param);
            var bs = Encoding.UTF8.GetBytes(param);
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded;charset=" + Encoding.UTF8.WebName;
            req.Headers.Add("sign", Sign(requestdatas)); //放入签名信息在消息头
            req.ContentLength = bs.Length;
            Console.WriteLine("请求头信息:");
            Console.WriteLine(req.Headers.ToString());
            Console.WriteLine("---------------------------");
            Console.WriteLine("请求体信息:");
            Console.WriteLine(param);
            Console.WriteLine("---------------------------");

            //发送请求
            using (var reqStream = req.GetRequestStream())
            {
                reqStream.Write(bs, 0, bs.Length);
                reqStream.Close();
            }

            //获取请求
            using (var response = (HttpWebResponse) req.GetResponse())
            {
                var responseStream = response.GetResponseStream();

                if (responseStream == null)
                {
                    return;
                }
                using (var reader = new StreamReader(responseStream, Encoding.UTF8))
                {
                    var responseData = reader.ReadToEnd();
                    Console.WriteLine("返回信息:");
                    Console.WriteLine(responseData);
                    Console.WriteLine("---------------------------");
                }
            }
        }

        /// <summary>
        ///     数据签名
        /// </summary>
        /// <param name="requestdatas"></param>
        /// <returns></returns>
        private static string Sign(string requestdatas)
        {
            var ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            //5分钟内有效
            var exp = ts.TotalMilliseconds + 30000;

            var payload = new Dictionary<string, object>
            {
                {"sub", "tester"},
                {"exp", exp},
                {"requestdatas", GetMd5(requestdatas)}
            };

            var privateKey =
                new X509Certificate2("F:/yongyouInvoice/speCertifcate.pfx", "password",
                    X509KeyStorageFlags.Exportable | X509KeyStorageFlags.MachineKeySet).PrivateKey as
                    RSACryptoServiceProvider;

            var token = JWT.Encode(payload, privateKey, JwsAlgorithm.PS256);

            return token;
        }

        /// <summary>
        ///     获取md5值
        /// </summary>
        /// <param name="requestdatas"></param>
        /// <returns></returns>
        private static string GetMd5(string requestdatas)
        {
            using (var md5Hash = MD5.Create())
            {
                var hash = GetMd5Hash(md5Hash, requestdatas);
                return hash;
            }
        }

        private static string GetMd5Hash(MD5 md5Hash, string input)
        {
            // Convert the input string to a byte array and compute the hash.
            var data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Create a new Stringbuilder to collect the bytes
            // and create a string.
            var sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data 
            // and format each one as a hexadecimal string.
            for (var i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }

        /// <summary>
        ///     构造邮件交付配置信息
        /// </summary>
        /// <returns></returns>
        private static string BuildEmailData()
        {
            var emailDatas = new List<Dictionary<string, object>>();
            var oneEmail = new Dictionary<string, object>
            {
                {"fpqqlsh", "1122334455667758"},
                {"address", "18101912713@163.com"}
            };
            emailDatas.Add(oneEmail);

            return JsonConvert.SerializeObject(emailDatas);
        }

        /// <summary>
        ///     构建短信交付配置
        /// </summary>
        /// <returns></returns>
        private static string BuildMobileData()
        {
            var mobileDatas = new List<Dictionary<string, object>>();
            var oneMobile = new Dictionary<string, object>
            {
                {"fpqqlsh", "1122334455667758"},
                {"address", "13111111111"}
            };
            mobileDatas.Add(oneMobile);

            return JsonConvert.SerializeObject(mobileDatas);
        }

        /// <summary>
        ///     构建url回调配置
        /// </summary>
        /// <returns></returns>
        private static string BuildUrlData()
        {
            var urlDatas = new List<Dictionary<string, object>>();
            var oneUrl = new Dictionary<string, object>
            {
                {"fpqqlsh", "1122334455667758"},
                {"url", "http://173919zc58.imwork.net/Test/RedirectResult.ashx"}
            };
            urlDatas.Add(oneUrl);

            return JsonConvert.SerializeObject(urlDatas);
        }

        /// <summary>
        ///     开票请求数据
        /// </summary>
        /// <returns></returns>
        private static string BuildRequestDatas()
        {
            var requestDatas = new List<Dictionary<string, object>>();
            //构造发票头
            var oneInvoice = new Dictionary<string, object>
            {
                {"FPQQLSH", "1122334455667758"},
                {"XSF_NSRSBH", "111222333456111"},
                {"ORGCODE","Y003"},
               // {"GMF_MC", "购买方名称"},
                {"JSHJ", 117}
            };
            requestDatas.Add(oneInvoice);

            var items = new List<Dictionary<string, object>>();
            oneInvoice.Add("items", items);

            //构造一个发票明细
            var oneItem = new Dictionary<string, object>
            {
                {"XMMC", "项目名称"},
                {"XMSL", 1},
                {"XMJSHJ", 117},
                {"SL", 0.17}
            };

            items.Add(oneItem);


            return JsonConvert.SerializeObject(requestDatas);
        }
        }
    }
