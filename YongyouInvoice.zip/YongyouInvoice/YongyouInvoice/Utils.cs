﻿using System.IO;
using System.Text;
using System.Web;
namespace YongyouInvoice
{
    /// <summary>
    /// 工具类
    /// </summary>
    public class Utils
    {
        public static string GetRequestData()
        {
            using (var stream = HttpContext.Current.Request.InputStream)
            {
                using (var reader = new StreamReader(stream, Encoding.UTF8))
                {
                    return reader.ReadToEnd();
                }
            }
        }
    }
}
